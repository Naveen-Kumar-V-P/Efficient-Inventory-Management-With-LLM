import streamlit as st
from transformers import BertTokenizer, BertForQuestionAnswering
import pandas as pd
import torch

# Load pre-trained model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForQuestionAnswering.from_pretrained('bert-base-uncased')

# Load your question-answer table (optional)
try:
  qa_data = pd.read_csv(r"C:\Users\Windows\Desktop\Main Projects\Efficient Inventory Management With LLM\sales Q&A.csv", encoding='latin1')
  questions = qa_data['Questions'].tolist()
  answers = qa_data['Answers'].tolist()
except FileNotFoundError:
  st.warning("Question-answer table not found. Expected at 'C:/Users/saima/OneDrive/Desktop/DATA SCIENCE/PROJECT NO-1/Sales Q and A Dataset/sales.csv'.")
  questions = []
  answers = []

def predict_answer(question):
  """Predicts answer to a question using the BertForQuestionAnswering model."""
  question_tokens = tokenizer(question, padding=True, truncation=True, return_tensors='pt')

  # Combine question tokens with empty context tokens
  input_ids = torch.cat([question_tokens['input_ids'], torch.zeros_like(question_tokens['input_ids'])], dim=1)
  attention_mask = torch.cat([torch.ones_like(question_tokens['attention_mask']), torch.zeros_like(question_tokens['attention_mask'])], dim=1)

  with torch.no_grad():
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    start_scores = outputs.start_logits
    end_scores = outputs.end_logits
    start_index = torch.argmax(start_scores)
    end_index = torch.argmax(end_scores) + 1
    predicted_answer = tokenizer.decode(question_tokens['input_ids'][0][start_index:end_index])
  return predicted_answer

# Streamlit App
st.title("Bert Question Answering System")

# Enhanced interface with a text area for multi-line questions
question = st.text_area("Enter your question:", height=100)

if st.button("Ask"):
  predicted_answer = predict_answer(question)
  st.write(f"**Question:** {question}")

  # Try finding the answer in the table (optional)
  try:
    answer_index = questions.index(question)
    expected_answer = answers[answer_index]
    st.write(f"**Expected Answer (from table):** {expected_answer}")
  except (ValueError, IndexError):  # Question not found in table or table not loaded
    pass

  st.write(f"**Predicted Answer:** {predicted_answer}")
